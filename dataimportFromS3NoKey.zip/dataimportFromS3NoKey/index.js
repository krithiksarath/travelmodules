"use strict";

// insert custom modules here
const config = require("./config");
const response = require("./response");

// insert node modules here
const request = require("request");
const _ = require("lodash");
const url = require("url");
const AWS = require("aws-sdk");
var net = require("net");

/*AWS.config.update({
  region: process.env.region,
  accessKeyId: process.env.access_key_id,
  secretAccessKey: process.env.secret_access_key
});*/

// main method
exports.handler = async (event, context, callback) => {
  try {
    let dataValue = await retrieveJSONFromS3({
      Bucket: config.elasticsearch.S3BucketName,
      Key: config.elasticsearch.S3BucketRegionFileName
    });

    console.log(datavalue);
  } catch (e) {
    console.log("Data import failed due to the error ::" + e);
    response.error(callback, response.status.INTERNAL_SERVER_ERROR, e.message);
  }
};

// custom methods

async function retrieveJSONFromS3(s3Params) {
  return new Promise((resolve, reject) => {
    try {
      console.log("S3 parameters : " + JSON.stringify(s3Params));
      var s3 = new AWS.S3();
      let jsonData = "";

      s3.getObject(s3Params, function(err, data) {
        if (err) {
          reject(err);
        }

        if (data === null) {
          console.log("S3 Bucket Returns null value");
        } else {
          jsonData = data.Body.toString();
          console.log("We are able to read the data from S3");
        }
        resolve(jsonData);
      });
    } catch (e) {
      console.log("Error while accessing S3::" + e);
    }
  });
}
