"use strict";

// insert node modules here
const response = require("./response");
const request = require("request");
const hotelBookingHistoryUrl =
  "http://www.mocky.io/v2/5be4008c2f00008800d9f2a7";
const flightBookingHistoryUrl =
  "http://www.mocky.io/v2/5be53aa32f000095000fc147";
let bookingHistory = [];
let past_trips = [];
let upcoming_trips = [];
// main method
exports.handler = async (event, context, callback) => {
  try {
    const hresponse = await getHotelBookingHistory();
    const fresponse = await getFlightsBookingHistory();
    response.success(callback, response.status.SUCCESS, bookingHistory);
  } catch (e) {
    console.log("Transaction History failed due to the error ::" + e);
    response.error(callback, response.status.INTERNAL_SERVER_ERROR, e.message);
  }
};

function getHotelBookingHistory() {
  try {
    return new Promise((resolve, reject) => {
      request(
        {
          url: hotelBookingHistoryUrl,
          method: "GET",
          json: true
        },
        (err, response, body) => {
          if (err) {
            console.log(
              " Error while Fetching the Hotel Transaction History - " + err
            );
            reject(err);
          }

          var hresult = populateResponse(body, "hotel");
          resolve(hresult);
        }
      );
    });
  } catch (e) {
    console.log("Error in getHotelBookingHistory" + e);
  }
}

function getFlightsBookingHistory() {
  try {
    return new Promise((resolve, reject) => {
      request(
        {
          url: flightBookingHistoryUrl,
          method: "GET",
          json: true
        },
        (err, response, body) => {
          if (err) {
            console.log(
              " Error while Fetching the Flights Transaction History - " + err
            );
            reject(err);
          }
          let result = populateResponse(body, "flights");
          resolve(result);
        }
      );
    });
  } catch (e) {
    console.log("Error in getFlightsBookingHistory" + e);
  }
}

function populateResponse(obj, propType) {
  var today = new Date();

  if (propType == "hotel") {
    obj.forEach(book => {
      var myDate = new Date(book.booking.checkOut);
      if (myDate > today) {
        upcoming_trips.push({
          itineraryId: book.itineraryId,
          bookingStatus: book.booking.bookingStatus,
          hotelName: book.booking.hotelName,
          checkIn: book.booking.checkIn,
          checkOut: book.booking.checkOut,
          image: book.booking.image,
          type: propType
        });
      } else {
        past_trips.push({
          itineraryId: book.itineraryId,
          bookingStatus: book.booking.bookingStatus,
          hotelName: book.booking.hotelName,
          checkIn: book.booking.checkIn,
          checkOut: book.booking.checkOut,
          image: book.booking.image,
          type: propType
        });
      }
    });
  } else if (propType == "flights") {
    obj.forEach(book => {
      var myDate = new Date(book.booking.outboundFlight.arrivalTime);
      if (myDate > today) {
        upcoming_trips.push({
          itineraryId: book.itineraryId,
          bookingStatus: book.booking.bookingStatus,
          departureCity: book.booking.outboundFlight.departureCity,
          arrivalCity: book.booking.outboundFlight.arrivalCity,
          travelDate: book.booking.outboundFlight.arrivalTime,
          type: propType
        });
      } else {
        past_trips.push({
          itineraryId: book.itineraryId,
          bookingStatus: book.booking.bookingStatus,
          departureCity: book.booking.outboundFlight.departureCity,
          arrivalCity: book.booking.outboundFlight.arrivalCity,
          travelDate: book.booking.outboundFlight.arrivalTime,
          type: propType
        });
      }
    });
    bookingHistory.push({
      past_trips: past_trips,
      upcoming_trips: upcoming_trips
    });
  }

  return bookingHistory;
}
