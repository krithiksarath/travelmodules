const config = {
  local: {
    expedia: {
      url: "https://test.ean.com/2.1",
      api_key: "4029cdoi17j0rqu7i1j5qd2l1i",
      secret: "3v3sjhr6u302h",
      user_agent: "RTMP/1.0.0"
    },
    aws: {
      access_key_id: "AKIAJG2FB45ZOKIDHTAA",
      secret_access_key: "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",
      region: "ap-southeast-1"
    }
  },
  development: {
    expedia: {
      url: "https://test.ean.com/2.1",
      api_key: "4029cdoi17j0rqu7i1j5qd2l1i",
      secret: "3v3sjhr6u302h",
      user_agent: "RTMP/1.0.0"
    }
  },
  production: {
    expedia: {
      url: "https://api.ean.com/2.1",
      api_key: "4029cdoi17j0rqu7i1j5qd2l1i",
      secret: "3v3sjhr6u302h",
      user_agent: "RTMP/1.0.0"
    }
  }
};

module.exports = config[process.env.NODE_ENV || "local"];
