// dependencies
const AWS = require("aws-sdk");
const config = require("./config");
//get reference to Rekognition client
const rekognition = new AWS.Rekognition({ apiVersion: "2016-06-27" });
//get reference to elasticsearch
const elasticsearch = require("elasticsearch");
//get reference to connection handler for Amazon ES
const httpawses = require("http-aws-es");
//get credentials for elastic search client
// Lambda provided credentials
//get reference to elastic search client
//const elasticSearchHost =
// "search-image-index-and-search-qoksrs4iuarbjhvauldmgdk6hu.us-east-1.es.amazonaws.com";
const elasticSearchAWSHost =
  "https://search-property-search-l63bfa4nk6vofsz4kfd4t2w6f4.ap-southeast-1.es.amazonaws.com";
/*AWS.config = new AWS.Config();
AWS.config.accessKeyId = "AKIAJG2FB45ZOKIDHTAA";
AWS.config.secretAccessKey = "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";
//AWS.config.region = "region";
const myCredentials = new AWS.EnvironmentCredentials("AWS");*/

var creds = new AWS.Credentials(
  "AKIAJG2FB45ZOKIDHTAA",
  "H7iO1TmL80/2rcEQihRNk0H1QqUQzO5h1DUdl5oY",
  null
);

const es = elasticsearch.Client({
  hosts: elasticSearchAWSHost,
  connectionClass: httpawses,

  amazonES: {
    region: "ap-southeast-1",
    credentials: creds
  }
});
const esPropertiesIndex = "properties";

//const elasticSearchLocalHost = 'http://localhost:9200/';

exports.handler = (event, context, callback) => {
  insertToES();
  // events
  //const searchTerm = event.queryParams.name;
  // elasticsearch search template call
  /*es.search({
	  index: esPropertiesIndex,
	  type: 'labels',
	  body: {
	    query: {
	      match: {
	        tags: {
	            query: searchTerm,
	            operator: 'or'
	        }
	      }
	    }
	  }
	},function(err,resp,status) {
	    var result = resp.hits.hits.map(x => x._source);
	    console.log(JSON.stringify(result));
	    callback(null, result);
	});	*/
};

// insert template
const insertToES = () => {
  console.log("Started Inserting...");
  //insert to elasticsearch index
  es.index(
    {
      index: esPropertiesIndex,
      type: "labels",
      body: {
        id: "45252522",
        name: "Ritz Carlton"
        //tags: "[tag1, tag2, tag3]"
      }
    },
    function(err, data) {
      //log the labels to cloudwatch logs
      console.log("errors from es: " + err);
      //console.log(JSON.stringify(labels));
    }
  );
};

const esTestData = () => {};
