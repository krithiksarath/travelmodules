// dependencies
const AWS = require("aws-sdk");
const config = require("./config");
//get reference to Rekognition client
const rekognition = new AWS.Rekognition({ apiVersion: "2016-06-27" });
//get reference to elasticsearch
const elasticsearch = require("elasticsearch");
//get reference to connection handler for Amazon ES
const httpawses = require("http-aws-es");

//get credentials for elastic search client
const elasticSearchHost =
  "search-properties-s4lyapenizs2wdq2glilesc2t4.ap-southeast-1.es.amazonaws.com";

const esPropertiesIndex = "properties";

AWS.config.update({
  region: "ap-southeast-1",
  accessKeyId: "AKIAJG2FB45ZOKIDHTAA",
  secretAccessKey: "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"
});

const myCredentials = new AWS.EnvironmentCredentials("AWS");
const es = elasticsearch.Client({
  hosts: elasticSearchHost,
  connectionClass: httpawses,
  amazonES: {
    // region: "ap-southeast-1",
    credentials: myCredentials
  }
});

var searchResponse = {
  status: [],
  data: []
};

exports.handler = (event, context, callback) => {
  let searchTerm = event.query.property_name;
  searchTerm = searchTerm.toLowerCase();

  searchPropety(searchTerm);
};

const searchPropety = searchTerm => {
  //insert to elasticsearch index
  es.search(
    {
      index: esPropertiesIndex,
      type: "propertyListing",
      body: {
        query: {
          // regexp: {
          //   property_name: searchTerm + ".*"
          // }
          wildcard: {
            property_name: "*" + searchTerm + "*"
          }
        }
      }
    },
    function(error, response, status) {
      if (error) {
        console.log(" Method search error: " + error);
        searchResponse.status.push({
          code: error,
          description: "Failure"
        });
      } else {
        console.log("--- Search Result ---");
        searchResponse.status.push({
          code: 200,
          description: "Success"
        });
        response.hits.hits.forEach(function(hit) {
          searchResponse.data.push({
            id: hit._source.property_id,
            name: hit._source.property_name,
            type: hit._source.property_type
          });
        });
      }
      console.log(searchResponse);
      return searchResponse;
    }
  );
};

const esTestData = () => {};
