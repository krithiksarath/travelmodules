// dependencies
const AWS = require("aws-sdk");
const config = require("./config");
//get reference to Rekognition client
const rekognition = new AWS.Rekognition({ apiVersion: "2016-06-27" });
//get reference to elasticsearch
const elasticsearch = require("elasticsearch");
//get reference to connection handler for Amazon ES
const httpawses = require("http-aws-es");

//get credentials for elastic search client
const elasticSearchHost =
  "search-properties-s4lyapenizs2wdq2glilesc2t4.ap-southeast-1.es.amazonaws.com";

const esPropertiesIndex = "properties";

AWS.config.update({
  region: "ap-southeast-1",
  accessKeyId: "AKIAJG2FB45ZOKIDHTAA",
  secretAccessKey: "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" //,
  // endpoint: new AWS.Endpoint("http://localhost:8000")
});

const myCredentials = new AWS.EnvironmentCredentials("AWS");
const es = elasticsearch.Client({
  hosts: elasticSearchHost,
  connectionClass: httpawses,
  amazonES: {
    // region: "ap-southeast-1",
    credentials: myCredentials
  }
});
exports.handler = (event, context, callback) => {
  //insertToES();
  let searchTerm = event.query.property_name;
  searchTerm = searchTerm.toLowerCase();

  console.log("Search Term ::" + searchTerm);
  searchPropety(searchTerm);
};

const insertToES = () => {
  //insert to elasticsearch index
  es.index(
    {
      index: esPropertiesIndex,
      type: "propertyListing",
      body: {
        property_id: "3",
        property_name: "Australia",
        property_type: "Country"
      }
    },
    function(err, data) {
      //log the labels to cloudwatch logs
      if (err) {
        console.log("error");
      } else {
        console.log("Inserted...");
      }
    }
  );
};

const searchPropety = searchTerm => {
  //insert to elasticsearch index
  es.search(
    {
      index: esPropertiesIndex,
      type: "propertyListing",
      body: {
        query: {
          // regexp: {
          //   property_name: searchTerm + ".*"
          // }
          wildcard: {
            property_name: "*" + searchTerm + "*"
          }
        }
      }
    },
    function(error, response, status) {
      if (error) {
        console.log("New Method search error: " + error);
      } else {
        console.log("--- New Method Response ---");
        console.log(response);
        // callback(null, JSON.parse(response));
        console.log("--- New Method Hits ---");
        response.hits.hits.forEach(function(hit) {
          console.log(hit);
        });
      }
    }
  );
};

const esTestData = () => {};
