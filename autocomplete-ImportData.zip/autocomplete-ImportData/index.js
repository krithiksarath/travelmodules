"use strict";

// insert custom modules here
const config = require("./config");
const database = require("./database");
const response = require("./response");

// insert node modules here
const request = require("request");
const _ = require("lodash");
const Joi = require("Joi");
const url = require("url");
const querystring = require("querystring");
const crypto = require("crypto");
const CryptoJS = require("crypto-js");
const fs = require("fs");
const zlib = require("zlib");
const gunzip = require("gunzip-file");
const progress = require("progress-stream");
const ip = require("ip");
var jsonlines = require("jsonlines");
const LineByLineReader = require("line-by-line");
var sizeof = require("object-sizeof");
var JSONC = require("jsoncomp/src/JSONC.js");

// dependencies
const AWS = require("aws-sdk");
//get reference to Rekognition client
const rekognition = new AWS.Rekognition({ apiVersion: "2016-06-27" });
//get reference to elasticsearch
const elasticsearch = require("elasticsearch");
//get reference to connection handler for Amazon ES
const httpawses = require("http-aws-es");

//get credentials for elastic search client
const elasticSearchHost =
  "search-properties-s4lyapenizs2wdq2glilesc2t4.ap-southeast-1.es.amazonaws.com";

const esPropertiesIndex = "properties";

AWS.config.update({
  region: "ap-southeast-1",
  accessKeyId: "AKIAJG2FB45ZOKIDHTAA",
  secretAccessKey: "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"
});

const myCredentials = new AWS.EnvironmentCredentials("AWS");
const es = elasticsearch.Client({
  hosts: elasticSearchHost,
  connectionClass: httpawses,
  requestTimeout: Infinity, // Tested
  keepAlive: true, // Tested
  amazonES: {
    credentials: myCredentials
  },
  httpOptions: { timeout: 500000 }
});

var property_id;
var property_name;
var property_type;

// main method
exports.handler = async (event, context, callback) => {
  try {
    clearPropertyRegionData();
    //loadRegionDataFromJSONFile();
    loadPropertiesDataFromJSONLFile();
    //console.log("Data Persisted Successfully...");
  } catch (e) {
    console.log(e);
    response.error(callback, response.status.INTERNAL_SERVER_ERROR, e.message);
  }
};

// custom methods

function insertData(id, name, type) {
  try {
    es.index(
      {
        index: esPropertiesIndex,
        type: "propertyListing",
        body: {
          property_id: id,
          property_name: name,
          property_type: type
        }
      },
      function(err, data) {
        //log the labels to cloudwatch logs
        if (err) {
          console.log("**********error message" + err);
        } else {
          // console.log("Inserted...");
        }
      }
    );
  } catch (e) {
    console.log("Error in insertData" + e);
  }
}

function loadRegionDataFromJSONFile() {
  try {
    fs.readFile("japan_regions.json", "utf8", function(err, data) {
      if (err) throw err;
      var obj = JSON.parse(data);
      let values = _.values(obj);

      for (var key in obj) {
        // console.log(obj[key]);

        _.forEach(obj[key], region => {
          property_id = region.id;
          property_name = region.name_full;
          property_type = region.type;

          // property_id = JSON.stringify(region.id);
          // property_name = JSON.stringify(region.name_full);
          // property_type = JSON.stringify(region.type);

          // console.log(property_id + "-" + property_name + "-" + property_type);

          insertData(property_id, property_name, property_type);
        });
      }
    });
  } catch (e) {
    console.log("Error in loadRegionDataFromJSONFile :" + e);
    response.error(callback, response.status.INTERNAL_SERVER_ERROR, e.message);
  }
}

function loadPropertiesDataFromJSONLFile() {
  try {
    let lr = new LineByLineReader("propertycatalog.expediacollect.en-US.jsonl");

    lr.on("line", line => {
      try {
        property_id = JSON.parse(line).property_id;
        property_name = JSON.parse(line).name;
        property_type = JSON.parse(line).category.name;
        lr.pause();
        insertData(property_id, property_name, property_type);
        lr.resume();
      } catch (e) {
        console.log(e);

        response.error(
          callback,
          response.status.INTERNAL_SERVER_ERROR,
          e.message
        );
      }
    });

    lr.on("end", () => {
      console.log("Comleted Reading the file");
    });
  } catch (e) {
    console.log("Error in loadPropertiesDataFromJSONLFile :" + e);
  }
}

function clearPropertyRegionData() {
  try {
    es.deleteByQuery(
      {
        index: "properties",
        type: "propertyListing",
        body: {
          query: {
            wildcard: {
              property_type: "*"
            }
          }
        }
      },
      function(err, data) {
        //log the labels to cloudwatch logs
        if (err) {
          console.log("error message" + err);
        } else {
          console.log("Deleted...");
        }
      }
    );
  } catch (e) {
    console.log("Error in clearPropertyRegionData :" + e);
  }
}

function unzipGZipFile() {
  try {
    gunzip(
      "propertycatalog.expediacollect.en-US.jsonl.gz",
      "propertycatalog.expediacollect.en-US.jsonl",
      () => {
        console.log("gunzip done!");
      }
    );
  } catch (e) {
    console.log("Error in unzipGZipFile :" + e);
  }
}
