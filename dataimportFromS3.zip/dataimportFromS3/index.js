"use strict";

// insert custom modules here
const config = require("./config");
const response = require("./response");

// insert node modules here
const request = require("request");
const _ = require("lodash");
const url = require("url");
const fs = require("fs");
const LineByLineReader = require("line-by-line");
var readline = require("readline");
const AWS = require("aws-sdk");

AWS.config.update({
  region: config.aws.region,
  accessKeyId: config.aws.access_key_id,
  secretAccessKey: config.aws.secret_access_key
});

var property_id;
var property_name;
var property_type;

// main method
exports.handler = async (event, context, callback) => {
  try {
    await clearIndexData();
    console.log("All the data in the index has been cleared");
    await loadRegionDataFromJSONFile();
    console.log("Region Data has been populated successfully");
    await loadPropertiesDataFromJSONLFile();
    console.log("Properties Data has been populated successfully");
    console.log("Data import completed successfully..");
  } catch (e) {
    console.log("Data import failed due to the error ::" + e);
    response.error(callback, response.status.INTERNAL_SERVER_ERROR, e.message);
  }
};

// custom methods

async function retrieveJSONFromS3(s3Params) {
  return new Promise((resolve, reject) => {
    try {
      console.log("S3 parametersSSS : " + JSON.stringify(s3Params));
      var s3 = new AWS.S3();
      let jsonData = "";

      s3.getObject(s3Params, function(err, data) {
        if (err) {
          reject(err);
        }

        if (data === null) {
          console.log("S3 Bucket Returns null value");
        } else {
          jsonData = data.Body.toString();
          console.log("We are able to read the data from S3");
        }
        resolve(jsonData);
      });
    } catch (e) {
      console.log("Error while accessing S3::" + e);
    }
  });
}

function insertDataToIndex(regionpropData) {
  try {
    return new Promise((resolve, reject) => {
      request(
        {
          url: config.elasticsearch.elasticSearchHost + "/_bulk",
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: regionpropData
        },
        (err, response, body) => {
          if (err) {
            console.log(
              " Error while insert -Response ::" + JSON.stringify(response)
            );
            reject(err);
          }
          resolve(response);
        }
      );
    });
  } catch (e) {
    console.log("Error in insertDataToIndex" + e);
  }
}

async function loadRegionDataFromJSONFile() {
  try {
    let dataValue = await retrieveJSONFromS3({
      Bucket: config.elasticsearch.S3BucketName,
      Key: config.elasticsearch.S3BucketRegionFileName
    });

    var totalRecord = 0;
    var obj = JSON.parse(dataValue);

    let values = _.values(obj);
    let records = [];
    var count = 0;
    var totalRecord = 0;
    for (var key in obj) {
      var record = "";
      _.forEach(obj[key], region => {
        try {
          record = record.concat(
            JSON.stringify({
              index: {
                _index: config.elasticsearch.index,
                _type: config.elasticsearch.indexType
              }
            }) +
              "\n" +
              JSON.stringify({
                id: region.id,
                name: region.name_full,
                type: region.type,
                idType: "regionId"
              }) +
              "\n"
          );

          count++;

          if (count === 100) {
            totalRecord = totalRecord + count;
            insertDataToIndex(record).then(
              function(res) {
                //log the labels to cloudwatch logs
                console.log("Total Region Records inserted :" + count);
              },
              function(err) {
                console.log("Error while inserting in NEW Methd..." + err);
              }
            );
            count = 0;
            record = "";
          }
        } catch (e) {
          console.log("Error while inserting the data " + e);
        }
      });

      insertDataToIndex(record).then(
        function(res) {
          totalRecord = totalRecord + count;
          //log the labels to cloudwatch logs
          console.log("Total Records inserted :" + count);
        },
        function(err) {
          console.log("Error while inserting in NEW Methd..." + err);
        }
      );
      count = 0;
      record = "";
    }
    // });
    console.log("Total inserted region data records" + totalRecord);
  } catch (e) {
    console.log("---Error in loadRegionDataFromJSONFile :" + e);
  }
}

async function loadPropertiesDataFromJSONLFile() {
  try {
    var S3 = new AWS.S3();
    //Create read stream from S3
    var s3ReadStream = S3.getObject({
      Bucket: config.elasticsearch.S3BucketName,
      Key: config.elasticsearch.S3BucketPropertiesFileName
    }).createReadStream();

    //Pass the S3 read stream into the readline interface to break into lines
    var lr = readline.createInterface({
      input: s3ReadStream,
      terminal: false
    });

    var count = 0;
    var record = "";
    var totalRecord = 0;
    lr.on("line", line => {
      try {
        property_id = JSON.parse(line).property_id;
        property_name = JSON.parse(line).name;
        property_type = JSON.parse(line).category.name;

        record = record.concat(
          JSON.stringify({
            index: {
              _index: config.elasticsearch.index,
              _type: config.elasticsearch.indexType
            }
          }) +
            "\n" +
            JSON.stringify({
              id: property_id,
              name: property_name,
              type: property_type,
              idType: "propertyId"
            }) +
            "\n"
        );

        count++;
        lr.pause();
        if (count === 100) {
          insertDataToIndex(record).then(
            function(res) {
              totalRecord = totalRecord + count;
            },
            function(err) {
              console.log("Error while inserting in NEW Methd..." + err);
            }
          );
          count = 0;
          record = "";
        }
        lr.resume();
      } catch (e) {
        console.log("Error while inserting the properties data:" + e);
      }
    });

    lr.on("close", () => {
      insertDataToIndex(record).then(
        function(res) {
          totalRecord = totalRecord + count;
          //log the labels to cloudwatch logs
          console.log("Total Property Records inserted :" + totalRecord);
        },
        function(err) {
          console.log("Error while inserting Property Data..." + err);
        }
      );
      console.log("Completed Reading the file");
    });
  } catch (e) {
    console.log("Error in loadPropertiesDataFromJSONLFile :" + e);
  }
}

function clearIndexData() {
  try {
    return new Promise((resolve, reject) => {
      request(
        {
          url:
            config.elasticsearch.elasticSearchHost +
            "/" +
            config.elasticsearch.index,
          method: "DELETE"
        },
        (err, response, body) => {
          if (err) {
            console.log(
              " Error while Deleting the index data ::" +
                JSON.stringify(response)
            );
            reject(err);
          }

          resolve(response);
        }
      );
    });
  } catch (e) {
    console.log("Error in clearIndexData" + e);
  }
}
