const config = {
  local: {
    expedia: {
      url: "https://test.ean.com/2.1",
      api_key: "4029cdoi17j0rqu7i1j5qd2l1i",
      secret: "3v3sjhr6u302h",
      user_agent: "RTMP/1.0.0"
    },
    elasticsearch: {
      elasticSearchHost:
        "https://search-autocompletedataimport-wyge7hnb6ieu32hp5tnuwt66xy.ap-southeast-1.es.amazonaws.com",
      index: "autocompletedataimport",
      indexType: "autocompletedataimportType",
      S3BucketName: "dbs-s3-mp-travel-hotels",
      S3BucketRegionFileName: "all_regions.json",
      S3BucketPropertiesFileName: "propertycatalog.expediacollect.en-US.jsonl"
    }
  },
  development: {
    expedia: {
      url: "",
      api_key: "",
      secret: "",
      user_agent: "RTMP/1.0.0"
    },
    aws: {
      access_key_id: "",
      secret_access_key: "",
      region: ""
    }
  },
  production: {
    expedia: {
      url: "",
      api_key: "",
      secret: "",
      user_agent: "RTMP/1.0.0"
    },
    aws: {
      access_key_id: "",
      secret_access_key: "",
      region: ""
    }
  }
};

module.exports = config[process.env.NODE_ENV || "local"];
