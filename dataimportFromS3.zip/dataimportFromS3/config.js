const config = {
  local: {
    expedia: {
      url: "https://test.ean.com/2.1",
      api_key: "4029cdoi17j0rqu7i1j5qd2l1i",
      secret: "3v3sjhr6u302h",
      user_agent: "RTMP/1.0.0"
    },
    aws: {
      access_key_id: "AKIAITBM6WSOT5L5GQ3Q",
      secret_access_key: "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",
      region: "ap-southeast-1"
    },
    elasticsearch: {
      /* elasticSearchHost:
        "https://search-autocompletedata-gj7sxmdc3orsrbvsadr64wri2m.ap-southeast-1.es.amazonaws.com",
      index: "autocompletedata",
      indexType: "autocompletedataType",*/
      elasticSearchHost:
        "https://search-traveldatanew-wwv7gpaidpoorko2zgr4tnafiq.ap-southeast-1.es.amazonaws.com",
      index: "traveldatanew",
      indexType: "traveldatanewType",
      S3BucketName: "dbs-s3-mp-travel-hotels",
      S3BucketRegionFileName: "all_regions.json",
      // S3BucketRegionFileName: "japan_regions.json" //,
      S3BucketPropertiesFileName: "propertycatalog.expediacollect.en-US.jsonl"
      //S3BucketPropertiesFileName: "propertiesdata.jsonl"
    }
  },
  development: {
    expedia: {
      url: "",
      api_key: "",
      secret: "",
      user_agent: "RTMP/1.0.0"
    },
    aws: {
      access_key_id: "",
      secret_access_key: "",
      region: ""
    }
  },
  production: {
    expedia: {
      url: "",
      api_key: "",
      secret: "",
      user_agent: "RTMP/1.0.0"
    },
    aws: {
      access_key_id: "",
      secret_access_key: "",
      region: ""
    }
  }
};

module.exports = config[process.env.NODE_ENV || "local"];
