const config = {
  local: {
    expedia: {
      url: "https://test.ean.com/2.1",
      api_key: "4029cdoi17j0rqu7i1j5qd2l1i",
      secret: "3v3sjhr6u302h",
      user_agent: "RTMP/1.0.0"
    },
    aws: {
      access_key_id: "AKIAIXQTJWEWUU623JHQ",
      secret_access_key: "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",
      region: "ap-southeast-1"
    },
    elasticsearch: {
      elasticSearchHost:
        "search-traveldata-76dao6codcwaoonrt2n3ui4gwq.ap-southeast-1.es.amazonaws.com",
      index: "traveldata",
      indexType: "travelDataType",
      S3BucketName: "dbs-s3-mp-travel-hotels",
      S3BucketRegionFileName: "all_regions.json"
    } 
  },
  development: {
    expedia: {
      url: "",
      api_key: "",
      secret: "",
      user_agent: "RTMP/1.0.0"
    },
    aws: {
      access_key_id: "",
      secret_access_key: "",
      region: ""
    }
  },
  production: {
    expedia: {
      url: "",
      api_key: "",
      secret: "",
      user_agent: "RTMP/1.0.0"
    },
    aws: {
      access_key_id: "",
      secret_access_key: "",
      region: ""
    }
  }
};

module.exports = config[process.env.NODE_ENV || "local"];
