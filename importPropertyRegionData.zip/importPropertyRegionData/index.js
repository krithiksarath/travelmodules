"use strict";

// insert custom modules here
const config = require("./config");
const response = require("./response");

// insert node modules here
const request = require("request");
const _ = require("lodash");
const url = require("url");
const fs = require("fs");
const progress = require("progress-stream");
var jsonlines = require("jsonlines");
const LineByLineReader = require("line-by-line");

// dependencies
const AWS = require("aws-sdk");
//get reference to Rekognition client
const rekognition = new AWS.Rekognition({ apiVersion: "2016-06-27" });
//get reference to elasticsearch
const elasticsearch = require("elasticsearch");
//get reference to connection handler for Amazon ES
const httpawses = require("http-aws-es");

AWS.config.update({
  region: config.aws.region,
  accessKeyId: config.aws.access_key_id,
  secretAccessKey: config.aws.secret_access_key
});

const myCredentials = new AWS.EnvironmentCredentials("AWS");
const es = elasticsearch.Client({
  hosts: config.elasticsearch.elasticSearchHost,
  connectionClass: httpawses,
  requestTimeout: Infinity, // Tested
  keepAlive: false, // Tested
  amazonES: {
    credentials: myCredentials
  },
  httpOptions: { timeout: 1000000 }
});

var property_id;
var property_name;
var property_type;
var idType;

// main method
exports.handler = async (event, context, callback) => {
  try {
    clearPropertyRegionData();
    loadRegionDataFromJSONFile();
    //loadPropertiesDataFromJSONLFile();
    //console.log("Data Persisted Successfully...");
  } catch (e) {
    console.log(e);
    response.error(callback, response.status.INTERNAL_SERVER_ERROR, e.message);
  }
};

// custom methods

async function retrieveJSONFromS3(s3Params) {
  return new Promise((resolve, reject) => {
    console.log("S3 parameters : " + JSON.stringify(s3Params));
    var s3 = new AWS.S3();
    s3.getObject(s3Params, function(err, data) {
      if (err) {
        console.log(err);
        reject(err);
        reject("Unable to retrieve the S3 file : " + s3Params);
      }

      let jsonData = data.Body.toString();

      resolve(jsonData);
    });
  });
}

function insertData(id, name, type, idType) {
  try {
    //console.log(id + "-" + name + "-" + type + "-" + idType);
    es.index(
      {
        index: config.elasticsearch.index,
        type: config.elasticsearch.indexType,
        body: {
          property_id: id,
          property_name: name,
          property_type: type,
          idType: idType
        }
      },
      function(err, data) {
        //log the labels to cloudwatch logs
        if (err) {
          console.log("**********error message" + err);
        } else {
          console.log("Inserted...");
        }
      }
    );
  } catch (e) {
    console.log("Error in insertData" + e);
  }
}

async function loadRegionDataFromJSONFile() {
  try {
    let dataval = await retrieveJSONFromS3({
      Bucket: config.elasticsearch.S3BucketName,
      Key: config.elasticsearch.S3BucketRegionFileName
    });

    // console.log(obj);
    var obj = JSON.parse(dataval);
    //console.log(obj);
    let values = _.values(obj);
    // console.log(values);
    for (var key in obj) {
      // console.log(obj[key]);

      _.forEach(obj[key], region => {
        property_id = region.id;
        property_name = region.name_full;
        property_type = region.type;

        try {
          /*  console.log(
            property_id +
              "-" +
              property_name +
              "-" +
              property_type +
              "-" +
              idType
          );*/
          insertData(property_id, property_name, property_type, "regionId");
        } catch (e) {
          console.log("Error while inserting the data " + e);
        }
      });
    }
  } catch (e) {
    console.log("---Error in loadRegionDataFromJSONFile :" + e);
  }
}

function clearPropertyRegionData() {
  try {
    es.deleteByQuery(
      {
        index: config.elasticsearch.index,
        type: config.elasticsearch.indexType,
        body: {
          query: {
            wildcard: {
              property_type: "*"
            }
          }
        }
      },
      function(err, data) {
        //log the labels to cloudwatch logs
        if (err) {
          console.log("error message" + err);
        } else {
          console.log("Deleted...");
        }
      }
    );
  } catch (e) {
    console.log("Error in clearPropertyRegionData :" + e);
  }
}
