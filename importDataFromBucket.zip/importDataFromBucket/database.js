// insert custom modules here
const config = require("./config");

// insert node modules here
const AWS = require("aws-sdk");
AWS.config.update({
  accessKeyId: config.aws.access_key_id,
  secretAccessKey: config.aws.secret_access_key,
  region: config.aws.region
});
const docClient = new AWS.DynamoDB.DocumentClient();
docClient.scan;
exports.retrieveAll = (tableName, queryObject) => {
  return new Promise((resolve, reject) => {
    queryObject.TableName = tableName;

    docClient.scan(queryObject, (err, data) => {
      if (err) {
        reject(err);
      } else {
        resolve(data.Items);
      }
    });
  });
};

exports.batchGet = (tableName, keys) => {
  return new Promise((resolve, reject) => {
    const params = {
      RequestItems: {}
    };
    params.RequestItems[tableName] = {
      Keys: keys
    };

    docClient.batchGet(params, (err, data) => {
      if (err) {
        reject(err);
      } else {
        resolve(data.Responses[tableName]);
      }
    });
  });
};

exports.retrieveRecord = (tableName, key) => {
  return new Promise((resolve, reject) => {
    const queryObject = {
      TableName: tableName,
      Key: key
    };

    docClient.get(queryObject, (err, data) => {
      if (err) {
        reject(err);
      } else {
        resolve(data.Item);
      }
    });
  });
};

exports.insertRecord = (tableName, object) => {
  return new Promise((resolve, reject) => {
    const queryObject = {
      TableName: tableName,
      Item: object
    };

    docClient.put(queryObject, (err, data) => {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

exports.updateRecord = (tableName, key, object) => {
  return new Promise((resolve, reject) => {
    const queryObject = {
      TableName: tableName,
      Key: key,
      UpdateExpression: "set message = :m",
      ExpressionAttributeValues: {
        ":m": object.message
      },
      ReturnValues: "UPDATED_NEW"
    };

    docClient.update(queryObject, (err, data) => {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

exports.removeRecord = (tableName, key) => {
  return new Promise((resolve, reject) => {
    const queryObject = {
      TableName: tableName,
      Key: key
    };

    docClient.docClient.delete(queryObject, (err, data) => {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

exports.batchInsertRecord = (tableName, requests) => {
  return new Promise((resolve, reject) => {
    console.log("batch write startiiing....");
    console.log("SIZE IS: " + requests.length);

    let params = {
      RequestItems: {}
    };
    params.RequestItems[tableName] = requests;

    // console.log(tableName);
    // console.log("batch write starts....");
    //console.log(JSON.stringify(params));
    docClient.batchWrite(params, (err, data) => {
      //console.log("ERRORR IS:" + err);
      if (err) {
        console.log("issue in batch write ....");
        reject(err);
      } else {
        //console.log("batch write success....");
        resolve(data);
      }
    });
  });
};

exports.countLogins = function(property_id, tableName, callback) {
  return new Promise((resolve, reject) => {
    var params = {
      TableName: tableName,
      KeyConditionExpression: "#property_id = :property_id",
      ExpressionAttributeNames: {
        "#property_id": "property_id"
      },
      ExpressionAttributeValues: {
        ":property_id": property_id
      },
      Select: "COUNT"
    };

    // docClient.query(params, callback);

    docClient.query(params, (err, data) => {
      if (err) {
        console.log("s");
        reject(err);
      } else {
        console.log("f");
        resolve(data);
      }
    });
  });
};
