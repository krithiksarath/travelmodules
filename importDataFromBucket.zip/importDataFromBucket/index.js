"use strict";

// insert custom modules here
const config = require("./config");
const database = require("./database");
const response = require("./response");

// insert node modules here
const request = require("request");
const _ = require("lodash");
//const Joi = require("Joi");
const url = require("url");
const fs = require("fs");
const progress = require("progress-stream");
var jsonlines = require("jsonlines");
const LineByLineReader = require("line-by-line");

// dependencies
const AWS = require("aws-sdk");
//get reference to Rekognition client
const rekognition = new AWS.Rekognition({ apiVersion: "2016-06-27" });
//get reference to elasticsearch
const elasticsearch = require("elasticsearch");
//get reference to connection handler for Amazon ES
const httpawses = require("http-aws-es");

//get credentials for elastic search client
// const elasticSearchHost_old =
//   "search-properties-7v7yac7re65fw4kc6djbtum6mu.ap-southeast-1.es.amazonaws.com";

const elasticSearchHost =
  "search-traveldata-76dao6codcwaoonrt2n3ui4gwq.ap-southeast-1.es.amazonaws.com";

//const elasticSearchHost =
//"search-properties-s4lyapenizs2wdq2glilesc2t4.ap-southeast-1.es.amazonaws.com";

const esPropertiesIndex = "travelDataIndex";

AWS.config.update({
  region: "ap-southeast-1",
  accessKeyId: "AKIAJU2MLTQE2OLCXSLA",
  secretAccessKey: "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"
});

const myCredentials = new AWS.EnvironmentCredentials("AWS");
const es = elasticsearch.Client({
  hosts: elasticSearchHost,
  connectionClass: httpawses,
  requestTimeout: Infinity, // Tested
  keepAlive: false, // Tested
  amazonES: {
    credentials: myCredentials
  },
  httpOptions: { timeout: 1000000 }
});

var property_id;
var property_name;
var property_type;
var idType;

// main method
exports.handler = async (event, context, callback) => {
  try {
    // clearPropertyRegionData();
    loadRegionDataFromJSONFile();
    //loadPropertiesDataFromJSONLFile();
    //console.log("Data Persisted Successfully...");
  } catch (e) {
    console.log(e);
    response.error(callback, response.status.INTERNAL_SERVER_ERROR, e.message);
  }
};

// custom methods

async function retrieveJSONFromS3(s3Params) {
  return new Promise((resolve, reject) => {
    console.log("S3 parameters : " + JSON.stringify(s3Params));
    var s3 = new AWS.S3();
    s3.getObject(s3Params, function(err, data) {
      if (err) {
        console.log(err);
        reject(err);
        reject("Unable to retrieve the S3 file : " + s3Params);
      }
      //console.log("Data value is ::" + JSON.stringify(data));
      // let jsonData = JSON.parse(data);

      let jsonData = data.Body.toString();
      // console.log("Data value is ::" + jsonData);

      resolve(jsonData);
    });
  });
}

function insertData(id, name, type, idType) {
  try {
    //console.log(id + "-" + name + "-" + type + "-" + idType);
    es.index(
      {
        index: esPropertiesIndex,
        type: "travelDataType",
        body: {
          property_id: id,
          property_name: name,
          property_type: type,
          idType: idType
        }
      },
      function(err, data) {
        //log the labels to cloudwatch logs
        if (err) {
          console.log("**********error message" + err);
        } else {
          console.log("Inserted...");
        }
      }
    );
  } catch (e) {
    console.log("Error in insertData" + e);
  }
}

async function loadRegionDataFromJSONFile() {
  try {
    let dataval = await retrieveJSONFromS3({
      Bucket: "sarathnathamani",
      Key: "japan_regions.json"
    });
    // console.log(obj);
    var obj = JSON.parse(dataval);
    //console.log(obj);
    let values = _.values(obj);
    // console.log(values);
    for (var key in obj) {
      // console.log(obj[key]);

      _.forEach(obj[key], region => {
        property_id = region.id;
        property_name = region.name_full;
        property_type = region.type;

        try {
          //console.log(property_id + "-" + property_name + "-" + property_type);
          insertData(property_id, property_name, property_type, "regionId");
        } catch (e) {
          console.log("Error while inserting the data " + e);
        }
      });
    }
  } catch (e) {
    console.log("---Error in loadRegionDataFromJSONFile :" + e);
    // response.error(callback, response.status.INTERNAL_SERVER_ERROR, e.message);
  }
}

function clearPropertyRegionData() {
  try {
    es.deleteByQuery(
      {
        index: esPropertiesIndex,
        type: "travelDataType",
        body: {
          query: {
            wildcard: {
              property_type: "*"
            }
          }
        }
      },
      function(err, data) {
        //log the labels to cloudwatch logs
        if (err) {
          console.log("error message" + err);
        } else {
          console.log("Deleted...");
        }
      }
    );
  } catch (e) {
    console.log("Error in clearPropertyRegionData :" + e);
  }
}
